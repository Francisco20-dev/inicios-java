/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sumaresta;
import java.util.Scanner;
/**
 *
 * @author lisbe
 */
public class SumaResta {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        try{
            Scanner leer = new Scanner (System.in);
        double Peso,Altura,IMC;
        System.out.println("-----calculadora IMC---- ");
        System.out.println("ingrese su peso en Kg : ");
        Peso = leer.nextDouble();
        
        System.out.println("ingrese su altura en metros : ");
        Altura= leer.nextDouble();
        
       IMC= Peso/(Altura*Altura);
        System.out.printf("su IMC es de: %.2f\n", IMC);
            
        }catch(Exception e){
            System.out.println("ERRor");
        }
        
    }
    
}
